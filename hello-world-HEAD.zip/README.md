mithrL — short stack, great taste!
